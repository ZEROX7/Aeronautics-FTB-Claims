FTB-style GUI redo for Aeronautics FTB Claims

Files:
- src/main/resources/assets/aeroclaims_ftb/textures/screen/claim-menu.png
- src/main/resources/assets/aeroclaims_ftb/textures/block/claim_block.png
- src/main/resources/assets/aeroclaims_ftb/lang/en_us_merge.json
- patches/ClaimSettingsScreen-ftb-layout.patch

Important:
1. Replace your old claim-menu.png with this one.
2. Replace your old claim_block.png with this one.
3. Merge en_us_merge.json into your existing en_us.json, do not overwrite unless your file only has these keys.
4. Apply the patch manually if it does not apply cleanly. The important size is imageWidth=190 and imageHeight=178.
5. Reposition buttons to the coordinates listed in the patch comments.
